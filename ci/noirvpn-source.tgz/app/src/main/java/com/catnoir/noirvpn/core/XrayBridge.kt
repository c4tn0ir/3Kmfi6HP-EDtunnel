package com.catnoir.noirvpn.core

import com.catnoir.noirvpn.model.VpnProfile
import libXray.DialerController
import libXray.LibXray
import org.json.JSONArray
import org.json.JSONObject

object XrayBridge {
    init {
        LibXray.touch()
    }

    data class InvokeResult(val success: Boolean, val data: Any?, val error: String?)

    fun registerDialerController(controller: DialerController) {
        LibXray.registerDialerController(controller)
        LibXray.registerListenerController(controller)
    }

    fun setDns(controller: DialerController, endpoint: String = "1.1.1.1:53") {
        LibXray.setDNS(controller, endpoint)
    }

    fun resetDns() {
        LibXray.resetDNS()
    }

    fun xrayVersion(): String? {
        val result = invoke("xrayVersion")
        return (result.data as? JSONObject)?.optString("version")
    }

    fun convertShareLink(link: String): JSONObject {
        val result = invoke("convertShareLinksToXrayJson", JSONObject().put("text", link))
        if (!result.success) error(result.error ?: "Не удалось разобрать профиль")
        return result.data as? JSONObject ?: error("libXray вернул пустой профиль")
    }

    fun testConfig(config: JSONObject) {
        val result = invoke("testXray", JSONObject().put("xrayJson", config.toString()))
        if (!result.success) error(result.error ?: "Xray config validation failed")
    }

    fun runConfig(config: JSONObject) {
        val result = invoke("runXray", JSONObject().put("xrayJson", config.toString()))
        if (!result.success) error(result.error ?: "Xray start failed")
    }

    fun stop() {
        invoke("stopXray")
    }

    fun isRunning(): Boolean {
        val result = invoke("getXrayState")
        return result.success && (result.data as? JSONObject)?.optBoolean("running", false) == true
    }

    fun ping(profiles: List<VpnProfile>, timeoutSeconds: Int = 5): Map<String, Long?> {
        if (profiles.isEmpty()) return emptyMap()
        if (isRunning()) return profiles.associate { it.id to it.latencyMs }

        val output = linkedMapOf<String, Long?>()
        profiles.chunked(5).forEach { batch ->
            val configs = JSONArray()
            val valid = mutableListOf<VpnProfile>()
            batch.forEach { profile ->
                runCatching {
                    val config = convertShareLink(profile.shareLink)
                    val outbounds = config.optJSONArray("outbounds") ?: error("outbounds missing")
                    if (outbounds.length() == 0) error("outbound missing")
                    val first = outbounds.getJSONObject(0)
                    val tag = "ping-${profile.id.take(10)}"
                    first.put("tag", tag)
                    configs.put(JSONObject().put("xrayJson", config.toString()).put("outboundTag", tag))
                    valid += profile
                }.onFailure { output[profile.id] = null }
            }
            if (valid.isEmpty()) return@forEach

            val payload = JSONObject()
                .put("configs", configs)
                .put("timeout", timeoutSeconds)
                .put("url", "https://www.gstatic.com/generate_204")
                .put("locationUrl", "")
            val result = invoke("pingBatch", payload)
            if (!result.success) {
                valid.forEach { output[it.id] = null }
                return@forEach
            }
            val results = (result.data as? JSONObject)?.optJSONArray("results")
            valid.forEachIndexed { index, profile ->
                val item = results?.optJSONObject(index)
                output[profile.id] = if (item?.optBoolean("success", false) == true) item.optLong("delay") else null
            }
        }
        return output
    }

    private fun invoke(method: String, payload: JSONObject? = null): InvokeResult {
        val request = JSONObject()
            .put("apiVersion", LibXray.LibXrayAPIVersion)
            .put("method", method)
        if (payload != null) request.put("payload", payload)
        val raw = LibXray.invoke(request.toString())
        val response = JSONObject(raw)
        return InvokeResult(
            success = response.optBoolean("success", false),
            data = if (response.has("data") && !response.isNull("data")) response.get("data") else null,
            error = response.optString("error").takeIf { it.isNotBlank() },
        )
    }
}
