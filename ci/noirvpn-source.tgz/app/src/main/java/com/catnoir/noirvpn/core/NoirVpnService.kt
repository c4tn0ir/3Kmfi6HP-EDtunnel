package com.catnoir.noirvpn.core

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.catnoir.noirvpn.MainActivity
import com.catnoir.noirvpn.R
import libXray.DialerController
import java.util.concurrent.Executors

class NoirVpnService : VpnService() {
    private val worker = Executors.newSingleThreadExecutor()
    private var tun: ParcelFileDescriptor? = null
    private var activeProfileName: String? = null

    private val controller = object : DialerController {
        override fun protectFd(fd: Long): Boolean = protect(fd.toInt())
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        XrayBridge.registerDialerController(controller)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopTunnel()
            ACTION_START -> {
                val link = intent.getStringExtra(EXTRA_LINK).orEmpty()
                val name = intent.getStringExtra(EXTRA_NAME).orEmpty().ifBlank { "NoirVPN" }
                startForeground(NOTIFICATION_ID, notification("Подключение · $name"))
                worker.execute { startTunnel(link, name) }
            }
        }
        return START_NOT_STICKY
    }

    override fun onRevoke() {
        stopTunnel()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopTunnel()
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun startTunnel(link: String, name: String) {
        activeProfileName = name
        TunnelRuntime.connecting(name)
        try {
            if (link.isBlank()) error("Пустой профиль")
            stopCoreOnly()

            val builder = Builder()
                .setSession("NoirVPN")
                .setMtu(1500)
                .addAddress("10.66.0.2", 30)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("1.1.1.1")
                .addAddress("fd66:6e6f:6972::2", 126)
                .addRoute("::", 0)
                .addDnsServer("2606:4700:4700::1111")

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) builder.setMetered(false)

            tun = builder.establish() ?: error("Android не создал TUN интерфейс")
            val fd = tun?.fd ?: error("TUN fd отсутствует")

            XrayBridge.setDns(controller)
            val config = XrayConfigFactory.runtimeConfig(link, fd)
            XrayBridge.testConfig(config)
            XrayBridge.runConfig(config)
            if (!XrayBridge.isRunning()) error("Xray core не перешёл в running")

            TunnelRuntime.connected(name)
            val nm = getSystemService(NotificationManager::class.java)
            nm.notify(NOTIFICATION_ID, notification("Подключено · $name"))
        } catch (t: Throwable) {
            TunnelRuntime.error(name, t.message ?: t.javaClass.simpleName)
            stopCoreOnly()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun stopCoreOnly() {
        runCatching { XrayBridge.stop() }
        runCatching { XrayBridge.resetDns() }
        runCatching { tun?.close() }
        tun = null
    }

    private fun stopTunnel() {
        stopCoreOnly()
        activeProfileName = null
        TunnelRuntime.disconnected()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun notification(text: String): android.app.Notification {
        val pending = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_noirvpn)
            .setContentTitle("NoirVPN")
            .setContentText(text)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(pending)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "NoirVPN connection", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    companion object {
        const val ACTION_START = "com.catnoir.noirvpn.action.START"
        const val ACTION_STOP = "com.catnoir.noirvpn.action.STOP"
        const val EXTRA_LINK = "share_link"
        const val EXTRA_NAME = "profile_name"
        private const val CHANNEL_ID = "noirvpn_tunnel"
        private const val NOTIFICATION_ID = 1001

        fun start(context: Context, shareLink: String, name: String) {
            val intent = Intent(context, NoirVpnService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_LINK, shareLink)
                .putExtra(EXTRA_NAME, name)
            androidx.core.content.ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            context.startService(Intent(context, NoirVpnService::class.java).setAction(ACTION_STOP))
        }
    }
}
