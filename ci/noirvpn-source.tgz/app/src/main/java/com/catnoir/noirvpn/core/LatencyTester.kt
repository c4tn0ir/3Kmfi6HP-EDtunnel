package com.catnoir.noirvpn.core

import com.catnoir.noirvpn.data.NoirRepository
import com.catnoir.noirvpn.model.VpnProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LatencyTester(private val repository: NoirRepository) {
    suspend fun measure(profiles: List<VpnProfile>): Map<String, Long?> = withContext(Dispatchers.IO) {
        val result = XrayBridge.ping(profiles)
        result.forEach { (id, delay) -> repository.updateLatency(id, delay) }
        result
    }
}
