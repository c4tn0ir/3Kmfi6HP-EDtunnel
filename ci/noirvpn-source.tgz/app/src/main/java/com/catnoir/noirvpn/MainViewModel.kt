package com.catnoir.noirvpn

import android.app.Application
import android.content.Intent
import android.net.VpnService
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.catnoir.noirvpn.core.LatencyTester
import com.catnoir.noirvpn.core.NoirVpnService
import com.catnoir.noirvpn.core.TunnelRuntime
import com.catnoir.noirvpn.data.DeviceIdentity
import com.catnoir.noirvpn.data.NoirRepository
import com.catnoir.noirvpn.model.PlanCode
import com.catnoir.noirvpn.model.TunnelStatus
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(
    application: Application,
    private val repository: NoirRepository,
) : AndroidViewModel(application) {
    private val app = application
    private val latencyTester = LatencyTester(repository)
    val state = repository.state
    val tunnel = TunnelRuntime.state
    val screenState = combine(state, tunnel) { data, tunnel -> data to tunnel }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), state.value to tunnel.value)

    private val _openUrl = MutableSharedFlow<String>(extraBufferCapacity = 1)
    val openUrl = _openUrl.asSharedFlow()

    private val _vpnPermission = MutableSharedFlow<Intent>(extraBufferCapacity = 1)
    val vpnPermission = _vpnPermission.asSharedFlow()

    fun selectProfile(id: String) = repository.selectProfile(id)

    fun toggleTunnel() {
        val snapshot = tunnel.value
        if (snapshot.status == TunnelStatus.CONNECTED || snapshot.status == TunnelStatus.CONNECTING) {
            NoirVpnService.stop(app)
            return
        }
        val profile = state.value.selectedProfile ?: return
        val permission = VpnService.prepare(app)
        if (permission != null) {
            _vpnPermission.tryEmit(permission)
        } else {
            connectSelected()
        }
    }

    fun connectSelected() {
        val profile = state.value.selectedProfile ?: return
        NoirVpnService.start(app, profile.shareLink, profile.name)
    }

    fun refresh() = viewModelScope.launch {
        runCatching { repository.refreshAll(DeviceIdentity.hwid(app)) }
    }

    fun syncAccount() = viewModelScope.launch {
        runCatching { repository.syncAccount() }
    }

    fun pingAll() = viewModelScope.launch {
        runCatching { latencyTester.measure(state.value.profiles) }
    }

    fun setNoirSubscription(url: String) = viewModelScope.launch {
        runCatching { repository.setNoirSubscription(url, DeviceIdentity.hwid(app)) }
    }

    fun addExternalProvider(name: String, url: String) = viewModelScope.launch {
        runCatching { repository.addExternalProvider(name, url) }
    }

    fun updateProfile(firstName: String, lastName: String, username: String) {
        repository.updateUser(firstName, lastName, username)
    }

    fun buy(plan: PlanCode) = viewModelScope.launch {
        runCatching { repository.createOrder(plan) }
            .onSuccess { order ->
                if (!order.checkoutUrl.isNullOrBlank()) {
                    _openUrl.tryEmit(order.checkoutUrl)
                }
            }
    }

    fun consumeMessage() = repository.consumeMessage()
}
