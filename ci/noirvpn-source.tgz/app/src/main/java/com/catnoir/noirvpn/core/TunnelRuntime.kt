package com.catnoir.noirvpn.core

import com.catnoir.noirvpn.model.TunnelSnapshot
import com.catnoir.noirvpn.model.TunnelStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object TunnelRuntime {
    private val _state = MutableStateFlow(TunnelSnapshot())
    val state: StateFlow<TunnelSnapshot> = _state.asStateFlow()

    fun connecting(name: String) {
        _state.value = TunnelSnapshot(TunnelStatus.CONNECTING, name)
    }

    fun connected(name: String) {
        _state.value = TunnelSnapshot(TunnelStatus.CONNECTED, name)
    }

    fun disconnected() {
        _state.value = TunnelSnapshot()
    }

    fun error(name: String?, error: String) {
        _state.value = TunnelSnapshot(TunnelStatus.ERROR, name, error)
    }
}
