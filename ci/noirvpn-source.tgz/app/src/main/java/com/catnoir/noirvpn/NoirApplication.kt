package com.catnoir.noirvpn

import android.app.Application
import com.catnoir.noirvpn.data.NoirApi
import com.catnoir.noirvpn.data.NoirRepository
import com.catnoir.noirvpn.data.NoirStore

class NoirApplication : Application() {
    lateinit var repository: NoirRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val store = NoirStore(this)
        val api = NoirApi()
        repository = NoirRepository(store, api)
    }
}
