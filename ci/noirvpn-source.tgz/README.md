# NoirVPN Android

Clean Android client for NoirVPN.

- Package: `com.catnoir.noirvpn`
- UI: Kotlin + Jetpack Compose + Material 3
- Core: official XTLS/libXray built from pinned source
- Protocols: VLESS/REALITY, Hysteria2, plus compatible external-provider links supported by libXray
- NoirVPN servers are pinned above external providers
- Basic entitlement exposes 3 direct NoirVPN routes
- Plus entitlement exposes 10 NoirVPN routes
- User profile model includes First Name, Last Name, Username and numeric User ID
- Store API is separated from the VPN engine so Messenger and Market can later share the same account model

The repository does not contain production signing secrets. Release APKs are signed outside public CI.
